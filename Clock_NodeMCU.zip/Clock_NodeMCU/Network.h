// Init network; returns true if successful
bool setupNetwork();
