void ntpSetup() ;
bool readNtpResponse( unsigned long &secsSince1900 ) ;
void sendNtpRequest() ;
