void setupTelnetServer() ;
void serviceTelnetServer() ;
char TelnetRead() ;
int TelnetWrite( const char * str ) ;
