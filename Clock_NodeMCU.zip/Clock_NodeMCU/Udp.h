void udpSetup(unsigned char* addr , unsigned int port ) ;
int sendUdp( char * data, int size ) ;
int readUdp( char * buf, int size ) ;
void reportMac() ;
void udpService( ) ;
bool udpActive () ;

