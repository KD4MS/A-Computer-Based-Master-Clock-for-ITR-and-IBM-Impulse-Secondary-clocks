void ntpSetup() ;
bool readNtpResponse( int *minutes , int * seconds ) ;
void sendNtpRequest() ;
