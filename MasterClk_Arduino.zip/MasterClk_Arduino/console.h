/*
   console.h
   Master Clock - Drives an IBM Impulse Secondary clock movement
    using the International Business Machine Time Protocols,
    Service Instructions No. 230, April 1, 1938,Form 231-8884-0
    By Phil Hord,  This code is in the public domain Sept 9, 2013
*/

// Show the time and A/B state to the console
void showTime() ;

// Show the A/B signal drop
void showSignalDrop() ;

// Read/write to console user interface
// Call this "service" routine frequently to allow user input and console output.
void consoleService() ;

// printf-like function for serial port or console
void p(const char *fmt, ... );

